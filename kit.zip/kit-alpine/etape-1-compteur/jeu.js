// ÉTAPE 1 — Le compteur
// Objectif : chaque clic sur le bouton ajoute une ligne de code au compteur.
// Il y a des « À TOI » ici ET dans index.html.

function jeu() {
  return {
    lignes: 0,

    cliquer() {
      // À TOI 3 : à chaque clic, le nombre de lignes doit augmenter de 1. Écris-le sur la ligne vide.

    },
  };
}
