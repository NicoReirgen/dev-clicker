# Dev Clicker

Aujourd'hui, tu crées un jeu de type clicker : chaque clic écrit du code, et tu recrutes une équipe qui code pour toi. À la fin, ton jeu est en ligne et se joue aussi sur téléphone.

On utilise **Alpine.js**, un petit framework utilisé par de vrais développeurs. Son idée : tu changes une donnée dans `jeu.js`, et la page se met à jour toute seule.

## Comment travailler

1. Ouvre le dossier de l'étape dans VS Code.
2. Ouvre `index.html` dans ton navigateur (double-clic sur le fichier).
3. Cherche les blocs **À TOI** dans `index.html` et `jeu.js`, et complète-les.
4. Enregistre (`Ctrl + S`), puis recharge la page (`F5`).

## Choisis ton parcours

| Parcours | Étapes | Ensuite |
|---|---|---|
| **Créatif** | 1 et 2 | Ouvre `version-finale` et transforme le jeu à ton image |
| **Classique** | 1 à 4 | Personnalise ta version |
| **Expert** | 1 à 6 | Défis ci-dessous |

Tous les parcours finissent par la mise en ligne.

## Les étapes

| Dossier | Objectif | C'est réussi quand… |
|---|---|---|
| `etape-1-compteur` | Le compteur | Chaque clic ajoute une ligne au compteur |
| `etape-2-boutique` | La boutique | On peut acheter un café, qui rapporte plus par clic |
| `etape-3-equipe` | L'équipe | Les stagiaires et collègues produisent des lignes chaque seconde |
| `etape-4-sauvegarde` | La sauvegarde | La progression survit à un rechargement de la page |
| `etape-5-succes` | Les succès | Des succès se débloquent avec une notification |
| `etape-6-bugs` | Le mini-jeu de débogage | Des bugs apparaissent, freinent l'équipe, et disparaissent quand on clique dessus |

**Tu es bloqué ?** Chaque dossier contient la solution de l'étape d'avant : compare ton code ou repars du dossier suivant.

## Les quatre mots d'Alpine à connaître

| Dans index.html | Ce que ça fait |
|---|---|
| `x-data="jeu()"` | Relie la page aux données de `jeu.js` |
| `x-text="lignes"` | Affiche une donnée, et la met à jour toute seule |
| `@click="cliquer()"` | Appelle une fonction quand on clique |
| `:disabled="lignes < prix"` | Change un attribut selon les données |

Et un cinquième pour les listes : `x-for="a in ameliorations"` répète un modèle pour chaque élément.

## Transforme le jeu à ton image

Tout se règle en haut de `version-finale/jeu.js` et de `style.css` :

- **Le thème :** un Pizza Clicker, un Foot Clicker, un Rap Clicker… Change `unite`, `iconeClic` et le titre dans `index.html`.
- **La boutique :** renomme les améliorations, change leurs icônes, prix et effets, ou ajoutes-en.
- **Les couleurs :** modifie les variables en haut de `style.css`.
- **Les succès :** invente les tiens.

Pour trouver des icônes, utilise `Windows + .` sur Windows, ou `Ctrl + Cmd + Espace` sur Mac.

## Défis pour aller plus loin

- **Bonus doré :** un bouton qui apparaît au hasard et double la production pendant 10 secondes.
- **Prestige :** recommencer à zéro contre un bonus permanent.
- **Statistiques :** temps de jeu, record de clics par seconde.
- **Son :** un petit son à chaque achat.

Tu peux utiliser l'IA pour les défis, à une condition : savoir expliquer le code obtenu.

## Mettre ton jeu en ligne avec GitHub Pages

1. Sur GitHub, crée un dépôt public appelé `mon-clicker`.
2. Clique sur **uploading an existing file** et dépose **le contenu** de ton dossier, pas le dossier lui-même. `index.html` doit se trouver à la racine du dépôt.
3. Clique sur **Commit changes**.
4. Va dans **Settings > Pages**, puis, sous **Branch**, choisis `main` et clique sur **Save**.
5. Attends une minute, puis recharge la page : ton lien apparaît en haut.
