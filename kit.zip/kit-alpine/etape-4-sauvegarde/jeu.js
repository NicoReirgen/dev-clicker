// ÉTAPE 4 — La sauvegarde
// Objectif : recharger la page (F5) sans perdre sa progression.
// Le navigateur peut garder du texte grâce à localStorage. JSON transforme nos données en texte, et inversement.

const CLE_SAUVEGARDE = "dev-clicker-v2:" + location.pathname;

function jeu() {
  return {
    ameliorations: [
      { id: "cafe", icone: "☕", nom: "Café", prix: 15, parClic: 1, parSeconde: 0, nombre: 0 },
      { id: "stagiaire", icone: "🧑‍🎓", nom: "Stagiaire", prix: 50, parClic: 0, parSeconde: 1, nombre: 0 },
      { id: "souris", icone: "🖱️", nom: "Souris gamer", prix: 250, parClic: 5, parSeconde: 0, nombre: 0 },
      { id: "senior", icone: "🧙", nom: "Dev senior", prix: 600, parClic: 0, parSeconde: 8, nombre: 0 },
      { id: "ia", icone: "🤖", nom: "Assistant IA", prix: 4000, parClic: 0, parSeconde: 50, nombre: 0 },
      { id: "datacenter", icone: "🏭", nom: "Data center", prix: 25000, parClic: 0, parSeconde: 300, nombre: 0 },
    ],
    lignes: 0,
    efface: false,

    get parClic() {
      let somme = 1;
      for (const amelioration of this.ameliorations) {
        somme = somme + amelioration.parClic * amelioration.nombre;
      }
      return somme;
    },

    get parSeconde() {
      let somme = 0;
      for (const amelioration of this.ameliorations) {
        somme = somme + amelioration.parSeconde * amelioration.nombre;
      }
      return somme;
    },

    init() {
      this.charger();
      setInterval(() => {
        this.lignes = this.lignes + this.parSeconde / 10;
      }, 100);
      // On sauvegarde toutes les 5 secondes, et juste avant de quitter la page.
      setInterval(() => this.sauvegarder(), 5000);
      window.addEventListener("beforeunload", () => this.sauvegarder());
    },

    sauvegarder() {
      if (this.efface) return;
      const partie = {
        lignes: this.lignes,
        achats: {},
      };
      // Chaque amélioration a son casier dans achats, étiqueté par son id.
      for (const amelioration of this.ameliorations) {
        partie.achats[amelioration.id] = { nombre: amelioration.nombre, prix: amelioration.prix };
      }
      // À TOI 1 : transforme la partie en texte (JSON) et range-la dans localStorage, sous la clé CLE_SAUVEGARDE.

    },

    charger() {
      // À TOI 2 : relis le texte rangé sous CLE_SAUVEGARDE et retransforme-le en objet.
      // S'il n'y a pas encore de sauvegarde, arrête la fonction : on garde la partie neuve.


      // À TOI 3 : remets les lignes sauvegardées dans this.lignes.

      // À TOI 4 : pour chaque amélioration, ouvre son casier partie.achats[amelioration.id].
      // S'il y a quelque chose dedans, remets le nombre et le prix sauvegardés.







    },

    recommencer() {
      if (!confirm("Effacer toute ta progression ?")) return;
      this.efface = true;
      localStorage.removeItem(CLE_SAUVEGARDE);
      location.reload();
    },

    cliquer() {
      this.lignes = this.lignes + this.parClic;
    },

    acheter(amelioration) {
      if (this.lignes < amelioration.prix) return;
      this.lignes = this.lignes - amelioration.prix;
      amelioration.nombre++;
      amelioration.prix = Math.ceil(amelioration.prix * 1.15);
    },

    description(amelioration) {
      let texte = "";
      if (amelioration.parClic) texte = texte + "+" + amelioration.parClic + " par clic ";
      if (amelioration.parSeconde) texte = texte + "+" + amelioration.parSeconde + " par seconde";
      return texte;
    },

    formater(nombre) {
      return Math.floor(nombre).toLocaleString("fr-FR");
    },
  };
}
