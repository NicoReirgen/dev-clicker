// ÉTAPE 3 — Ton équipe code pour toi
// Objectif : recruter des collègues qui écrivent des lignes toutes seules, chaque seconde.
// Nouveauté : au lieu d'un seul café, la boutique est une LISTE d'améliorations.
// Une seule fonction acheter() marche pour toutes : plus besoin de copier-coller.

function jeu() {
  return {
    ameliorations: [
      { id: "cafe", icone: "☕", nom: "Café", prix: 15, parClic: 1, parSeconde: 0, nombre: 0 },
      { id: "stagiaire", icone: "🧑‍🎓", nom: "Stagiaire", prix: 50, parClic: 0, parSeconde: 1, nombre: 0 },
      { id: "souris", icone: "🖱️", nom: "Souris gamer", prix: 250, parClic: 5, parSeconde: 0, nombre: 0 },
      { id: "senior", icone: "🧙", nom: "Dev senior", prix: 600, parClic: 0, parSeconde: 8, nombre: 0 },
      { id: "ia", icone: "🤖", nom: "Assistant IA", prix: 4000, parClic: 0, parSeconde: 50, nombre: 0 },
    ],
    lignes: 0,

    // Un « get » se calcule tout seul à partir des autres données.
    get parClic() {
      let somme = 1;
      for (const amelioration of this.ameliorations) {
        somme = somme + amelioration.parClic * amelioration.nombre;
      }
      return somme;
    },

    get parSeconde() {
      // À TOI 1 : sur le modèle de parClic juste au-dessus, additionne la production
      // par seconde de chaque amélioration (parSeconde × nombre). Ici, on part de 0.




      return 0; // remplace ce 0 par ton total
    },

    // Alpine appelle init() automatiquement au chargement de la page.
    init() {
      // À TOI 2 : toutes les 100 millisecondes, ajoute aux lignes un dixième de parSeconde.
      // Indice : cherche la fonction setInterval.



    },

    cliquer() {
      this.lignes = this.lignes + this.parClic;
    },

    acheter(amelioration) {
      if (this.lignes < amelioration.prix) return;
      this.lignes = this.lignes - amelioration.prix;
      amelioration.nombre++;
      amelioration.prix = Math.ceil(amelioration.prix * 1.15);
    },

    description(amelioration) {
      const effets = [];
      if (amelioration.parClic) effets.push("+" + amelioration.parClic + " par clic");
      if (amelioration.parSeconde) effets.push("+" + amelioration.parSeconde + " par seconde");
      return effets.join(" · ");
    },

    // Les lignes peuvent avoir des virgules : on affiche un nombre entier, joliment espacé.
    formater(nombre) {
      return Math.floor(nombre).toLocaleString("fr-FR");
    },
  };
}
