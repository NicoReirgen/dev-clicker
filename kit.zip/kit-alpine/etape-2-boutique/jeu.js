// ÉTAPE 2 — La boutique
// Objectif : acheter un café qui rapporte une ligne de plus à chaque clic.
// Tant que l'À TOI 1 n'est pas fait, la console affiche des erreurs : c'est normal.

function jeu() {
  return {
    lignes: 0,
    // À TOI 1 : sur les deux lignes vides, crée parClic (qui vaut 1) et cafe (prix 15, nombre 0).


    cliquer() {
      // À TOI 2 : un clic ne doit plus rapporter 1, mais la valeur de parClic. Modifie la ligne suivante.
      this.lignes = this.lignes + 1;
    },

    acheterCafe() {
      // À TOI 4 : si le joueur n'a pas assez de lignes pour payer le café, arrête la fonction.


      // À TOI 5 : le joueur paie le café : retire son prix de ses lignes.


      // À TOI 6 : il a un café de plus, et chaque clic lui rapporte une ligne de plus.



      // À TOI 7 : le café suivant coûte 15 % plus cher (arrondi à l'entier supérieur).

    },
  };
}
